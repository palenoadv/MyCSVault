def twenty_twenty_five():
    """Come up with the most creative expression that evaluates to 2025
    using only numbers and the +, *, and - operators (or ** and % if you'd like).

    >>> twenty_twenty_five()
    2025
    """
    return ______

